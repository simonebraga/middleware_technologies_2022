#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

// Creates an array of random numbers.
int *create_random_array(int num_elements, int max_value) {
  int *arr = (int *) malloc(sizeof(int)*num_elements);
  for (int i=0; i<num_elements; i++) {
    arr[i] = (rand() % max_value);
  }
  return arr;
}

// Remove element i by swapping with the last and decreasing the size
void swap_remove(int* array, int* size, int i) {
  *size -= 1;
  array[i] = array[*size];
}

// Process 0 selects a number num.
// All other processes have an array that they filter to only keep the elements
// that are multiples of num.
// Process 0 collects the filtered arrays and print them.
int main(int argc, char** argv) {
  // Maximum value for each element in the arrays
  const int max_val = 100;
  // Number of elements for each processor
  int num_elements_per_proc = 50;
  // Number to filter by
  int num_to_filter_by = 2;
  if (argc > 1) {
    num_elements_per_proc = atoi(argv[1]);
  }

  // Init random number generator
  srand(time(NULL));

  MPI_Init(NULL, NULL);

  int my_rank, world_size; 
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

  // Process 0 selects the num
  int num;
  if (my_rank == 0) {
    num = num_to_filter_by;
  }

  // TODO

  MPI_Bcast(&num, 1, MPI_INT, 0, MPI_COMM_WORLD);

  int* values = create_random_array(num_elements_per_proc, max_val);
  int s = num_elements_per_proc, i = 0;

  while (i < s) {
    if (values[i] % num != 0) {
      swap_remove(values, &s, i);
    } else {
      i += 1;
    }
  }

  int* sizes = NULL;
  int* displacements = NULL;
  int* results = NULL;
  int final_size = 0;

  if (my_rank == 0) {
    sizes = calloc(world_size, sizeof(int));
  }

  MPI_Gather(
    &s, 1, MPI_INT,
    sizes, 1,MPI_INT,
    0,
    MPI_COMM_WORLD
  );

  if (my_rank == 0) {
    displacements = calloc(world_size, sizeof(int));

    for (int i = 0; i < world_size; i++) {
      final_size += sizes[i];
    }
    for (int i = 1; i < world_size; i++) {
      displacements[i] = displacements[i-1] + sizes[i-1];
    }
    
    results = calloc(final_size, sizeof(int));
  }

  MPI_Gatherv(
    values, s, MPI_INT,
    results, sizes, displacements, MPI_INT,
    0,
    MPI_COMM_WORLD
  );

  if (my_rank == 0) {
    for (int i = 0; i < final_size; i++) {
      printf("[%d] ", results[i]);
    } printf("\n");
    free(sizes);
    free(displacements);
    free(results);
  }

  free(values);

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();
}
