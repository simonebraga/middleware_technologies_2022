#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

// Simple ping pong program to exemplify MPI_Send and MPI_Recs
// Assume only two processes
int main(int argc, char** argv) {
  const int tot_msgs = 100;
  
  MPI_Init(NULL, NULL);

  int my_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
  int other_rank = 1 - my_rank;

  int msg_num = 10;
  int msg_count = 0;

  if (my_rank == 0) {
    while(msg_count < msg_num) {
      MPI_Send(&msg_count, 1, MPI_INT, other_rank, 1, MPI_COMM_WORLD);
      MPI_Recv(&msg_count, 1, MPI_INT, other_rank, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      printf("Pong %d\n", msg_count);
    }
  } else if (my_rank == 1) {
    while(msg_count < msg_num) {
      MPI_Recv(&msg_count, 1, MPI_INT, other_rank, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      msg_count++;
      printf("Ping %d\n", msg_count);
      MPI_Send(&msg_count, 1, MPI_INT, other_rank, 1, MPI_COMM_WORLD);
    }
  }
  
  MPI_Finalize();
}
