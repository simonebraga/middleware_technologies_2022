
# Table of Contents

1.  [Avviare](#orgad33a95)
2.  [Persistenza](#org22f2a39)
    1.  [Named volume](#org03f4616)
    2.  [Bind mounts](#org5114178)



<a id="orgad33a95"></a>

# Avviare

Usando Docker, si può dare il seguente comando:

    docker run -it -p 1880:1880 -v node_red_data:/data --name <mynodered> nodered/node-red

che significa:

    docker run              - run this container, initially building locally if necessary
     -it                     - attach a terminal session so we can see what is going on
     -p 1880:1880            - connect local port 1880 to the exposed internal port 1880
     -v node_red_data:/data  - mount a docker named volume called `node_red_data` to the container /data directory so any changes made to flows are persisted
     --name <mynodered>        - give this machine a friendly local name
     nodered/node-red        - the image to base it on - currently Node-RED v1.2.0

Si può poi disaccoppiare il terminale premendo `Ctrl-p Ctrl-q`.
Per riattaccarlo (in modo da vedere l'output):

    docker attach <mynodered>

Dopodichè si può fermare e/o far ripartire usando i comandi

    docker start <mynodered>
    docker stop <mynodered>

Su WeBeep è linkata [la documentazione](https://nodered.org/docs/getting-started/docker) che spiega come far partire il container e altri consigli, come ad esempio aggiornare l'immagine e rendere persistenti i dati. Qui di seguito un indicazione di massima.


<a id="org22f2a39"></a>

# Persistenza

Per poter conservare i dati in caso di guasto, è necessario esporre uno storage all'applicazione. Si può fare in due modi: usando dei **named volume** o dei **bind mount**. La differenza sta in dove lo storage risiede fisicamente sulla macchina host (si veda [la documentazione](https://docs.docker.com/storage/#choose-the-right-type-of-mount)). Una volta che lo storage è montato comunque il container lo vede sempre nello stesso modo: una directory o un file.


<a id="org03f4616"></a>

## Named volume

Dalla [documentazione](https://docs.docker.com/storage/): *Volumes are stored in a part of the host filesystem which is **managed by Docker** (`/var/lib/docker/volumes/` on Linux). Non-Docker processes should not modify this part of the filesystem. Volumes are the best way to persist data in Docker.* I volumi sono di fatto delle directory montate nel container, ma che risiedono in una parte del file system che di solito è gestita solo da Docker, quindi sono isolate dal resto del sistema (e da altri container). Si può creare un volume con il comando `docker volume create`, oppure Docker ne potrebbe creare uno in automatico in fase di inizializzazione del container. Un volume può essere usato da più container contemporaneamente, oppure da nessuno. In quest'ultimo caso non viene cancellato. Per distruggere un volume si può invece dare il comando `docker volume prune`. Se non viene specificato nessun nome, Docker ne assegna uno casuale.

Quando si lancia Docker con il flag `-v node_red_data:/data`, si intende:

-   crea un volume chiamato `node_red_data` (la effettiva posizione le file system host non è importante, ma sarà indicativamente `/var/lib/docker/volumes/node_red_data`)
-   montalo nel container come `/data`


<a id="org5114178"></a>

## Bind mounts

Dalla documentazione: *Bind mounts may be stored anywhere on the host system. They may even be important system files or directories. Non-Docker processes on the Docker host or a Docker container can modify them at any time.* Rispetto ai volume, qualsiasi cartella può essere montata come bind mount. Questo può essere uno svantaggio o un pericolo, a seconda dell'uso.

