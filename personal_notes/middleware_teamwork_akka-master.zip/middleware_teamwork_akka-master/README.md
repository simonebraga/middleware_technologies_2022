# Teamwork repository for Akka
* [Java 11](https://openjdk.java.net/)
* [Maven 3.6.3](https://maven.apache.org/)
