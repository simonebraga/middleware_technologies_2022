
# Table of Contents

1.  [Akka](#org5d7b32f)
    1.  [Classe attore](#orgac696be)
        1.  [Actor references](#org7ed7cce)
    2.  [Classe main](#orga560ba0)
    3.  [Scambio messaggi](#org50f838c)
    4.  [Cambio policy](#orgb0e7e85)
    5.  [Stash](#orgf3f2b4b)
    6.  [Synchronous replies](#org41a1775)
    7.  [Attori distribuiti in rete](#org096e2e3)
    8.  [Fault tolerance e supervisione](#org35d62f0)
        1.  [Creare child](#orge9a320a)
    9.  [Cluster](#org27005aa)
2.  [Post](#org8fce3a8)



<a id="org5d7b32f"></a>

# Akka


<a id="orgac696be"></a>

## Classe attore

Per definire un **attore**, il modo più semplice è ereditare dalla classe `AbstractActor`. Queste classi dovranno necessariamente implementare il metodo `Receive createReceive()`, che specifica il dispatch dei messaggi. Nello specifico, il metodo avrà la forma

    public Receive createReceive(){
        return receiveBuilder()
    	.match(MessageClass.class, this::handlerMethod)
    	.build();
    }

dove ogni `match` specifica un filtro: il tipo di messaggio che intercetta, e il metodo da chiamare quando questo viene indivisuato.

Se interessa capire la sintassi del metodo, segue i [design pattern `builder`](https://refactoring.guru/design-patterns/builder) e [`chain of responsibility`](https://refactoring.guru/design-patterns/chain-of-responsibility).

I **metodi handler** prendono come parametro il messaggio in ingresso.

Gli attori hanno una durata **esplicita**: non sono distrutti automaticamente quando non sono più referenziati. Dopo averne creato uno, è compito del programmatore assicurarsi che venga deallocato correttamente. Questo permette anche di controllare il rilascio delle risorse. Tuttavia, [qui](https://doc.akka.io/docs/akka/current/general/actors.html#when-an-actor-terminates) vene anche detto che quando un attore termina libererà le proprie risorse.

Per rendere le cose più pratiche, si può creare le `Props` con un metodo statico nella classe attore:

    static Props props(){
     return Props.create(ActorClass.class);
    }


<a id="org7ed7cce"></a>

### Actor references

Gli attori vengono schermati dietro ad oggetti di tipo `ActorRef`. In questo modo, sono completamente disaccoppiati dal codice che li usa: un attore può essere spostato senza bisogno di riassegnare l'`ActorRef`. Gli attori non dovrebbero mostrare il loro stato: la comunicazione dovrebbe avvenire solo tramite messaggi.


<a id="orga560ba0"></a>

## Classe main

Per istanziare nuovi attori normalmente si crea un `ActorSystem`, che funge da factory(?), con il metodo statico `create`.

    final ActorSystem sys = ActorSystem.create("System"); //the name is custom

Un `ActorSystem` è un [gruppo gerarChico](https://doc.akka.io/api/akka/current/akka/actor/ActorSystem.html) di attori che condividono la stessa configurazione (indirizzi, dispatcher ecc.). E' anche il punto di ingresso per **creare** e **cercare** attori. E' tecnicamente possibile avere più `ActorSystem` per applicazione, ma normalmente se ne ha [uno per JVM](https://doc.akka.io/docs/akka/current/general/actor-systems.html).
Per istanziare un attore si usa l'`ActorSystem`, chiamando il metodo `actorOf()`, che chiede l'oggetto `Props` dell'attore, e il nome dell'attore. Le `Props` possono essere create con il metodo statico delle `Props` `create()`:

    Props p = Props.create(ActorClass.class);

Dopodichè l'attore può essere istanziato:

    ActorRef actor = sys.actorOf(p, "first actor");

Usando il metodo statico definito nell'attore, si può semplificare facendo:

    ActorRef actor = sys.actorOf(ActorClass.props(), "first actor");


<a id="org50f838c"></a>

## Scambio messaggi

Per inviare i messaggi

    receiver.tell(new Message(params), sender);

-   `receiver` è l'`ActorRef` destinatario.
-   `sender` è l'attore mittente. Se non serve specificarlo, si può usare `ActorRef.noSender()`. Per ottenere il mittente mentre si processa un messaggio, si può chiamare `sender()`, e ottenere un `ActorRef` a sè stessi con `self()`.


<a id="orgb0e7e85"></a>

## Cambio policy

Gli attori possono switchare a runtime le politiche di dispatCh dei messaggi, usando il metodo `getContext().become(newReceive)`, dove `newReceive` è un oggetto `Receive` creato come in `createReceiver()`. Es.:

    public Receive createReceive(){
        return disabled();
    }
    private Receive disabled(){
        return receiveBuilder()
    	.match(...)
    	.build();
    }
    private Receive enabled(){
        return receiveBuilder()
    	.match(...)
    	.build();
    }
    private void onMessageX(MessageX msg){
        getContext().become(enabled());
    }
    private void onMessageY(MessageY msg){
           getContext().become(disabled());
    }


<a id="orgf3f2b4b"></a>

## Stash

Si possono istanziare degli attori che abbiano un'area di memoria chiamata **stash**. Questi attori possono decidere di sospendere il processing dei messaggi, ma continuano a salvarli in una coda. Quando si svegliano, possono processarli. Il metodo `stash()` salva il messaggio corrente. Percio, è conveniente cambiare policy.

      public void onSimpleMessageEnabled(SimpleMessage msg){
    //        System.out.println("server: received " + msg.getText() + "\n");
    	sender().tell(msg, self());
        }
        public void onSimpleMessageDisabled(SimpleMessage msg){
    	System.out.println("stah: " + msg.getText());
    	stash();
        }
        public void onSleepMessage(SleepMessage msg){
    	getContext().become(disabled());
        }
    
        public void onWakeupMessage(WakeupMessage msg){
    	getContext().become(enavled());
    	this.unstashAll();
        }

dove `enabled()` e `disabled()` sono i due opportuni costruttori di `Receive`.


<a id="org41a1775"></a>

## Synchronous replies

Per avere delle risposte sincrone, usare solo i messaggi è complicato, perché bisognerebbe far risalire ogni risposta alla richiesta che l'ha chiesta. Invece, si possono usare dei **futures**, mediante il **pattern "ask"**

      //mittente: invia un messaggio attraverso il wrapper Patterns.ask()
     //il metodo si prenderà cura di inviare un messaggio e restituisce un future
       Future<Object> future = Patterns.ask(server, new IntMessage(8), 1000);
     //mittente: possiamo ora aspettare la risposta (se ancora non è arrivata) e ottenerla
     tipoDellaRisposta res = ((TipoDelMessagioRisposta) Await.result(future, Timeout.create(Duration.ofSeconds(1)).duration())).metodoGetter()
    
    //---------------
    //destinatario: ricevi la richiesta e invia una risposta come al solito
    sender().tell(msg, self())
    //nota: il destinatario non sa che la risposta verrà collegata ad un future


<a id="org096e2e3"></a>

## Attori distribuiti in rete

Gli attori possono essere distribuiti in rete in maniera **trasparente**. Una volta che sappiamo l'indirizzo dell'attore, possiamo inviargli messaggi come se fosse in locale. E gli `ActorRef` che si riferiscono ad altre macchine verranno propagati di conseguenza.
Akka supporta diversi protocolli. Limitandoci al TCP:

    //server
    akka {
        actor {
    	provider = remote
    	serializers {
    	    jackson-json = "akka.serialization.jackson.JacksonJsonSerializer"
    	}
    	serialization-bindings {
    	    "com.practice.exercise3.message.RemoteMessageInterface" = jackson-json
    	}
        }
        remote {
    	artery {
    	    transport = tcp
    	    canonical.hostname = "127.0.0.1"
    	    canonical.port = 6123
    	}
        }
    }
    
    
    //client
    akka {
        actor {
    	provider = remote
    	serializers {
    	    jackson-json = "akka.serialization.jackson.JacksonJsonSerializer"
    	}
    	serialization-bindings {
    	    "com.practice.exercise3.message.RemoteMessageInterface" = jackson-json
    	}
        }
        remote {
    	artery {
    	    transport = tcp
    	    canonical.hostname = "127.0.0.1"
    	    canonical.port = 6124
    	}
        }
    }

Per operare in rete, i processi devono acquisire le configurazioni. Per esempio,

    final Config config = ConfigFactory.parseFile(new File("src/main/resources/serverOrClient.conf"))

dopodichè si può creare l'`ActorSystem` come al solito

    final ActorSystem serverSystem = ActorSystem.create("ServerSystem", config);

passando però la configurazione al costruttore.

Il server (l'attore che riceve messaggi) può operare in maniera trasparente, ovvero il codice non cambia se i messaggi arrivano da locale o da remoto.

Il client (l'attore che invia i messaggi (TODO: per primo?)) invece deve prima trovare il server:

    final String serverAddress = "akka://ServerSystem@127.0.0.1:6123/user/ServerActor";
      final ActorSelection server = context().actorSelection(serverAddress)

Dove la stringa di indirizzo è

    protocollo://ServerSystem@IPAddr:Port/user/ClasseAttore  

Resta da capire se la stringa dopo la porta debba sempre iniziare con `/user/`. Teniamolo come TODO. Edit: guardare [qui il guardiano /user](https://doc.akka.io/docs/akka/current/supervision-classic.html)


<a id="org35d62f0"></a>

## Fault tolerance e supervisione

Gli attori all'interno di un `ActorSysem` sono organizzati in una **gerarchia** di supervisione. Il comportamento è immutabile e legato all'`ActorSystem`.
Alcune cose da notare:

-   Nella API **classica** gli attori quando lanciano un'eccezione e nessuna strategia di supervisione è definita sono restartati, nell'API **typed** sono stoppati.
-   Un **validation error** è un errore legato al fatto che un comando dato a un attore non è valido. E' consigliato gestirlo tramite i comportamento dell'attore. Un **failure** è invece qualcosa di inaspettato e non sotto il controllo dell'attore. E' consigliato affrontarlo usando delle eccezioni, perché normalemente gli attori possono fare poco a riguardo.

Alla cima dell'albero ci sono, in genere, degli attori supervisor speciali offerti dal framework Akka.

La filosofia di base è: quando c'é un failure, "let it crash". Lasciamo fermare l'attore, spostiamo la responsabilità della gestione al suo supervisore, e facciamo ripartire l'attore.
Per esempio, se un attore contiene dati importanti, può istanziare un attore figlio e far fare i lavori a lui: se crasha, può farlo ripartire senza perdere il suo stato.

**Da notare**: al riavvio, l'`ActorRef` è rimasto lo stesso, e la mailbox dell'attore non ancora processata viene consegnata.

Dalla [documentazione](https://doc.akka.io/docs/akka/current/supervision-classic.html#supervision-directives): *When a subordinate detects a failure (i.e. throws an exception), it suspends itself and all its subordinates and sends a message to its supervisor, signaling failure.*

Nell'attore si inseriscono questi campi, e si specifica la strategia nel seguente modo (vedere [la documentazione](https://doc.akka.io/docs/akka/current/fault-tolerance.html) per un esempio):

       private static SupervisorStrategy strategy =
           new OneForOneStrategy(
    			     10, //max num of retries
    			     Duration.ofMinutes(1), //within this time range
    			     DeciderBuilder.match(Exception.class, e -> SupervisorStrategy.restart()) //decider object, that specifies the supervision policy
    			     .build());
     @Override
     public SupervisorStrategy supervisorStrategy() {
         return strategy;
    }

Esistono due tipi di strategy:

-   La `OneForOneStrategy`, che indica che ogni attore child è trattato separatamente (quindi viene applicata solo su quello failing)
-   La `AllForOneStrategy`, che indica che l'azione specificata è eseguita per tutti gli attori, non solo quello failing (in genere usata solo in pochi casi in cui gli attori fratelli sono fortmente interonnessi)
    
    I child sono trattati finchè il numero di failures entro il time limit specificato è inferiore al numero massimo indicato nel costruttore, in questo caso al massimo 10 failure al minuto. Superato questo limite la policy divente bloccare i child. Eccezioni sono:
    
    -   `naxNrOfRetries = -1`, `withinTimeRange = Duration.Inf()`, allora i child possono essere fatti ripartire senza limite
    -   `maxNrOfRetries` non negativo, `withinTimeRange = Duration.Inf()`, allora non c'é limite di tempo: una volta che i retries superano il limite i child vengono stoppati.
        
        Ci sono diverse azioni che possono essere eseguite:
        
        -   `stop()`: ferma il child.
        -   `resume()`: fa ripartire l'attore child, mantenendone lo stato
        -   `restart)`: fa ripartire l'attore child, reiniziallizandone lo stato
        -   `escalate()`: propaga l'eccezione al parent

Opzionale: uno snippet che può essere utile per la programmazione funzionale:

    @Override
    public Receive createReceive() {
      return receiveBuilder()
          .match(
    	  Exception.class,
    	  exception -> {
    	    throw exception;
    	  })
          .match(Integer.class, i -> state = i)
          .matchEquals("get", s -> getSender().tell(state, getSelf()))
          .build();
    }


<a id="orge9a320a"></a>

### Creare child

Un attore è automaticamente supervisor di tutti gli attori creati **a partire dal suo contesto**.
Perciò si può creare un attore subordinato con il metodo `getContext().actorOf(Props props, String name)`. Per fermare un child si usa `getContext().stop(ActorRef actorDaFermare)`. In genere, se si vuole far creare un child, si può fare usando un `Future`.

    static class Supervisor extends AbstractActor {
        @Override
        public Receive createReceive() {
    	return receiveBuilder()
    	    .match(
    		   Props.class,
    		   props -> {
    		       getSender().tell(getContext().actorOf(props), getSelf());
    		   })
    	    .build();
        }
    }
    //codice esterno
    Props superprops = Props.create(Supervisor.class);
    ActorRef supervisor = system.actorOf(superprops, "supervisor");
    ActorRef child =
        (ActorRef) Await.result(ask(supervisor, Props.create(Child.class), 5000), timeout


<a id="org27005aa"></a>

## Cluster

Un buon punto per iniziare è [questa repo](https://github.com/mckeeh3/akka-typed-java-cluster.git), che spiega passo passo alcune cose fondamentali. Insieme c'è [questo video](https://www.youtube.com/watch?v=Ub1b_Eg4Z4w). Riporto dal `README.md` alcune definizioni:
"*Akka Cluster provides a fault-tolerant decentralized peer-to-peer based cluster membership service with no single point of failure or single point of bottleneck. It does this using gossip protocols and an automatic failure detector.*

*Akka cluster allows for building distributed applications, where one application or service spans multiple nodes.*"

Un'altra definizione informale: "Nodes of a single service (collectively called a cluster) require less decoupling. They share the same code and are deployed together, as a set, by a single team or individual. There might be two versions running concurrently during a rolling deployment, but deployment of the entire set has a single point of control. For this reason, intra-service communication can take advantage of Akka Cluster, failure management and actor messaging, which is convenient to use and has great performance."

Stando a Mottola: "*Imagine the cluster as a playground. Whereas in the remote excercise we used a textual configuration file to start up the actors, now you have the playground, which is the cluster. You deploy the actors in there, and where do they actually end up being executed is not entirely up to you, but determined by the cluster policies*".

[Un video](https://www.youtube.com/watch?v=Ad2DyOn4dlY) che può essere interessante in futuro e che si lega con **Kafka**

I **seed node** sono nodi speciali, usati come punto d'accesso per il cluster e che si occupano anche dello shutdown dei nodi. Quando un nodo vuole disconnettersi, trasferisce prima tutti i suoi attori a un altro nodo.


<a id="org8fce3a8"></a>

# Post

Pubblicata [domanda](https://stackoverflow.com/questions/70805315/what-do-akkas-actorsystem-corresponds-to-especially-in-cluster-technology), vediamo se otteniamo risposta.

Hi all, sorry if I'll be a little noobish here. I'm studying Java Akka and I'm struggling to grasp the exact meaning of an \`ActorSystem\`. I understand it's like an \`Actor\` factory, effectively creating the actors I may want to use in my application.

However, I am confused about two things, particularly regarding the **Akka cluster** usage.

-   The first is minor: in my application, is the \`ActorSystem\` unique? I've heard that while it is technically possible to have more than one, usually you only have **one system per JVM**. Is it true? **Would you ever need** to use more than one system in your project?
-   The big one: I need to familiarize with the Akka cluster mechanism. When I am distributing my application, what extra **conceptual** meaning do the \`ActorSystem\` get? Does it correspond to the notion of "node"? Or of "cluster"? For what I got, my machine correspond to a single cluster, which in turn comprises multiple nodes. Is it correct? Where do \`ActorSystem\`s kick in in this reasoning?
    
    Thanks in advance for your time!

