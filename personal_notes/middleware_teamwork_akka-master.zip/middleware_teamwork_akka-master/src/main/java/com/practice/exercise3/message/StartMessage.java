package com.practice.exercise3.message;

public class StartMessage {
}
