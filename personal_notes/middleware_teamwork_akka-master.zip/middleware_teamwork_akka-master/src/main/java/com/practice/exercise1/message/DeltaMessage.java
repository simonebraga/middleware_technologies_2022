package com.practice.exercise1.message;

public class DeltaMessage implements MessageInterface {

    private final int delta;

    public DeltaMessage() {
        this.delta = (int) (Math.random() * 10);
    }

    public int getDelta() {
        return this.delta;
    }
}
