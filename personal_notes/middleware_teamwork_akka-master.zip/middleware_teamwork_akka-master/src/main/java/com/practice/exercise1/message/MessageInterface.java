package com.practice.exercise1.message;

public interface MessageInterface {
}
