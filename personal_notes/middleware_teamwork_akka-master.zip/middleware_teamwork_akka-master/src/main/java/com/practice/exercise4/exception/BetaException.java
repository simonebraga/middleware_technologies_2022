package com.practice.exercise4.exception;

public class BetaException extends Exception {
}
