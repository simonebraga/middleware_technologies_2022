package com.practice.exercise3;

import akka.actor.AbstractActor;
import akka.actor.ActorSelection;
import akka.actor.Props;
import akka.pattern.Patterns;
import akka.util.Timeout;
import com.practice.exercise3.message.GetMessage;
import com.practice.exercise3.message.PutMessage;
import com.practice.exercise3.message.StartMessage;
import scala.concurrent.Await;
import scala.concurrent.Future;

import java.time.Duration;
import java.util.concurrent.TimeoutException;

public class ClientActor extends AbstractActor {

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(StartMessage.class, this::onStartMessage)
                .build();
    }

    private void onStartMessage(StartMessage msg) {

        final String serverAddress = "akka://ServerSystem@127.0.0.1:6123/user/ServerActor";
        final ActorSelection server = context().actorSelection(serverAddress);
        final Timeout timeout = Timeout.create(Duration.ofSeconds(3));

        Future<Object> future = Patterns.ask(server, new PutMessage("mariorossi", "mario.rossi@polimi.it"), timeout);

        try {
            Await.result(future, timeout.duration());
            System.out.println("CLIENT: Server confirmed PutMessage");
        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
        }

        future = Patterns.ask(server, new GetMessage("mariorossi"), timeout);

        try {
            String result = (String) Await.result(future, timeout.duration());
            System.out.println("CLIENT: I received <" + result + ">");
        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
        }

        future = Patterns.ask(server, new GetMessage("francescoverdi"), timeout);

        try {
            String result = (String) Await.result(future, timeout.duration());
            System.out.println("CLIENT: I received <" + result + ">");
        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    static Props props() {
        return Props.create(ClientActor.class);
    }
}
