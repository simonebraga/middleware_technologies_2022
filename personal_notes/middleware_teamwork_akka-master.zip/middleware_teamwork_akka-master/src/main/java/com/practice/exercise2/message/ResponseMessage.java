package com.practice.exercise2.message;

public class ResponseMessage implements MessageInterface {

    private final String value;

    public ResponseMessage(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
