package com.practice.exercise3.message;

public interface RemoteMessageInterface {
}
