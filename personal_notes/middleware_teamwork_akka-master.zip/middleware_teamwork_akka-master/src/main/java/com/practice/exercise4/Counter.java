package com.practice.exercise4;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.pattern.Patterns;
import com.practice.exercise4.message.AlphaMessage;
import com.practice.exercise4.message.BetaMessage;
import com.practice.exercise4.message.GammaMessage;
import scala.concurrent.Future;
import scala.concurrent.duration.Duration;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Counter {

    public static final int NORMAL_OP = 0;
    public static final int FAULT_OP = -1;

    private static void sleep() throws InterruptedException {
        TimeUnit.SECONDS.sleep(1);
    }

    public static void main(String[] args) {

        final Duration timeout = Duration.create(5, TimeUnit.SECONDS);

        final ActorSystem sys = ActorSystem.create("System");
        final ActorRef supervisor = sys.actorOf(CounterSupervisor.props(), "supervisor");

        try {

            final Future<Object> waitingForCounter = Patterns.ask(supervisor, Props.create(CounterActor.class), 5000);
            final ActorRef counter = (ActorRef) waitingForCounter.result(timeout, null);

            counter.tell(new AlphaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new AlphaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new AlphaMessage(NORMAL_OP), ActorRef.noSender());

            sleep();
            counter.tell(new AlphaMessage(FAULT_OP), ActorRef.noSender());  // Restart after this

            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());

            sleep();
            counter.tell(new BetaMessage(FAULT_OP), ActorRef.noSender());   // Resume after this

            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new BetaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new GammaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new GammaMessage(NORMAL_OP), ActorRef.noSender());
            sleep();
            counter.tell(new GammaMessage(NORMAL_OP), ActorRef.noSender());

            sleep();
            counter.tell(new GammaMessage(FAULT_OP), ActorRef.noSender());  // Escalate after this

            counter.tell(new AlphaMessage(NORMAL_OP), ActorRef.noSender());   // Should not be reached
            sys.terminate();

        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
        }

    }
}
