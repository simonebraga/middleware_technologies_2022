package com.practice.exercise2.message;

public interface MessageInterface {
}
