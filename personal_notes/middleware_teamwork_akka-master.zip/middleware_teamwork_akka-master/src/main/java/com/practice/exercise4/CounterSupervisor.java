package com.practice.exercise4;

import akka.actor.AbstractActor;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.japi.pf.DeciderBuilder;
import com.practice.exercise4.exception.AlphaException;
import com.practice.exercise4.exception.BetaException;
import com.practice.exercise4.exception.GammaException;

import java.time.Duration;

public class CounterSupervisor extends AbstractActor {

    @Override
    public Receive createReceive() { // When invoked, sends back a reference to a newly created actor of the type sent
        return receiveBuilder()
                .match(Props.class,
                        props -> getSender().tell(getContext().actorOf(props), self()))
                .build();
    }

    private static final SupervisorStrategy strategy = new OneForOneStrategy(
            10,
            Duration.ofMinutes(1),
            DeciderBuilder
                    // SupervisorStrategy.stop() is trivial, it just kills the actor
                    .match(AlphaException.class, e -> SupervisorStrategy.restart())
                    .match(BetaException.class, e -> SupervisorStrategy.resume())
                    .match(GammaException.class, e -> SupervisorStrategy.escalate())
                    .build());

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    static Props props() {
        return Props.create(CounterSupervisor.class);
    }
}
