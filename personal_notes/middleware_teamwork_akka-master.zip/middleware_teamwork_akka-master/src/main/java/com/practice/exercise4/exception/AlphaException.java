package com.practice.exercise4.exception;

public class AlphaException extends Exception {
}
