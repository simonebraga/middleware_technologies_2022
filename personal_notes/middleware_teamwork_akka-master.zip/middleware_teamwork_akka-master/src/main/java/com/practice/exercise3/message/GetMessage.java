package com.practice.exercise3.message;

import com.fasterxml.jackson.annotation.JsonCreator;

public class GetMessage implements RemoteMessageInterface {

    private final String key;

    @JsonCreator // Needed for classes with only 1 attribute
    public GetMessage(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
