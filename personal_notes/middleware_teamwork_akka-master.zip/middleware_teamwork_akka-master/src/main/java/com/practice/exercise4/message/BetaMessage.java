package com.practice.exercise4.message;

public class BetaMessage implements MessageInterface {

    private final int opCode;

    public BetaMessage(int opCode) {
        this.opCode = opCode;
    }

    public int getOpCode() {
        return opCode;
    }
}
