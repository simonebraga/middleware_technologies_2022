package com.practice.exercise3;

import akka.actor.AbstractActor;
import akka.actor.Props;
import com.practice.exercise3.message.GetMessage;
import com.practice.exercise3.message.PutMessage;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class ServerActor extends AbstractActor {

    private final Map<String, String> contactList = new HashMap<>();

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(PutMessage.class, this::onPutMessage)
                .match(GetMessage.class, this::onGetMessage)
                .build();
    }

    private void onPutMessage(PutMessage msg) throws InterruptedException {
        TimeUnit.SECONDS.sleep(1); // Simulates processing delay

        contactList.put(msg.getKey(), msg.getValue());
        System.out.println("SERVER: Put pair <" + msg.getKey() + ", " + msg.getValue() + ">");

        getSender().tell(Shared.completed, self());
    }

    private void onGetMessage(GetMessage msg) throws InterruptedException {
        TimeUnit.SECONDS.sleep(1); // Simulates processing delay

        final String key = msg.getKey();
        final String value = contactList.get(key);

        if (value != null) {
            System.out.println("SERVER: Retrieved value <" + value + "> for key <" + key + ">");
            getSender().tell(value, self());
        } else {
            System.out.println("SERVER: Key <" + key + "> not found, retrieved value <" + Shared.notFound + ">");
            getSender().tell(Shared.notFound, self());
        }
    }

    static Props props() {
        return Props.create(ServerActor.class);
    }
}
