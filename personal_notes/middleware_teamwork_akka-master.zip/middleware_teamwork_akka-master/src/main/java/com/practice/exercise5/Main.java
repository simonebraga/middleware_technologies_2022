package com.practice.exercise5;

import akka.actor.ActorSystem;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {

        final Config config1 = ConfigFactory.parseFile(new File("src/main/resources/node_1.conf"));
        final ActorSystem actorSystem1 = ActorSystem.create("ActorSystem", config1);
        actorSystem1.actorOf(SimpleClusterListener.props(), "Leader");

        TimeUnit.SECONDS.sleep(5);

        final Config config2 = ConfigFactory.parseFile(new File("src/main/resources/node_2.conf"));
        final ActorSystem actorSystem2 = ActorSystem.create("ActorSystem", config2);
        actorSystem2.actorOf(SimpleClusterSubscriber.props(), "Actor");

        //noinspection ResultOfMethodCallIgnored
        System.in.read();
        actorSystem1.terminate();
        actorSystem2.terminate();
    }
}