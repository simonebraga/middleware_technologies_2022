package com.practice.exercise4.message;

public class AlphaMessage implements MessageInterface {

    private final int opCode;

    public AlphaMessage(int opCode) {
        this.opCode = opCode;
    }

    public int getOpCode() {
        return opCode;
    }
}
