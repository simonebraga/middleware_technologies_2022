package com.practice.exercise2;

import akka.actor.AbstractActor;
import akka.actor.Props;
import com.practice.exercise2.message.GetMessage;
import com.practice.exercise2.message.PutMessage;
import com.practice.exercise2.message.ResponseMessage;

import java.util.HashMap;
import java.util.Map;

public class ContactServer extends AbstractActor {

    private final Map<String, String> contactList = new HashMap<>();

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(PutMessage.class, this::onPutMessage)
                .match(GetMessage.class, this::onGetMessage)
                .build();
    }

    private void onPutMessage(PutMessage msg) {
        contactList.put(msg.getKey(), msg.getValue());
        System.out.println("SERVER: Put pair <" + msg.getKey() + ", " + msg.getValue() + ">");
    }

    private void onGetMessage(GetMessage msg) {
        getSender().tell(new ResponseMessage(contactList.get(msg.getKey())), self());
        System.out.println("SERVER: Retrieved value for key <" + msg.getKey() + ">");
    }

    static Props props() {
        return Props.create(ContactServer.class);
    }
}
