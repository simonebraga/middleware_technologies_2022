package com.practice.exercise4.message;

public interface MessageInterface {
}
