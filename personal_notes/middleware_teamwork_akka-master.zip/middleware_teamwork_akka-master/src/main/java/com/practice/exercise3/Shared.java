package com.practice.exercise3;

public class Shared {

    public static final String completed = "#COMPLETED";
    public static final String notFound = "#NOTFOUND";
}
