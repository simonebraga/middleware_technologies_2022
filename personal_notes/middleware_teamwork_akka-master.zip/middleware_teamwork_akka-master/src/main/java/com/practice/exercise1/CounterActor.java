package com.practice.exercise1;

import akka.actor.AbstractActor;
import akka.actor.Props;
import com.practice.exercise1.message.*;

public class CounterActor extends AbstractActor {

	private int counter = 0;
	private boolean state;

	@Override
	public Receive createReceive() {
		this.state = true;
		return stateEnable();
	}

	private Receive stateEnable() {
		return receiveBuilder()
				.match(StateMessage.class, this::onStateMessage)
				.match(IncreaseMessage.class, this::onIncreaseMessage)
				.match(DecreaseMessage.class, this::onDecreaseMessage)
				.match(DeltaMessage.class, this::onDeltaMessage)
				.build();
	}

	private Receive stateDisable() {
		return receiveBuilder()
				.match(StateMessage.class, this::onStateMessage)	// Prevents the matching with the next clause
				.match(MessageInterface.class, this::onMessageInterface)
				.build();
	}

	private void onIncreaseMessage(IncreaseMessage msg) {
		counter++;
		System.out.println("ACTOR: Counter increased to " + counter);
	}

	private void onDecreaseMessage(DecreaseMessage msg) {
		counter--;
		System.out.println("ACTOR: Counter decreased to " + counter);
	}

	private void onDeltaMessage(DeltaMessage msg) {
		counter += msg.getDelta();
		System.out.println("ACTOR: Counter updated to " + counter);
	}

	private void onStateMessage(StateMessage msg) {
		this.state = !state;
		if (state) {
			getContext().become(stateEnable());
			System.out.println("ACTOR: STATE UPDATE - ENABLED");
		} else {
			getContext().become(stateDisable());
			System.out.println("ACTOR: STATE UPDATE - DISABLED");
		}
	}

	private void onMessageInterface(MessageInterface msg) {
		System.out.println("ACTOR: I am disabled, message cannot be handled");
	}

	static Props props() {
		return Props.create(CounterActor.class);
	}

}
