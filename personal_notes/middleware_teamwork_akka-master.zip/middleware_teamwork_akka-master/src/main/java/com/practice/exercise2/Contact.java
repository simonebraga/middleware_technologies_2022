package com.practice.exercise2;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import com.practice.exercise2.message.GetMessage;
import com.practice.exercise2.message.PutMessage;

import java.io.IOException;

public class Contact {

    public static void main(String[] args) throws IOException {

        final ActorSystem sys = ActorSystem.create("System");
        final ActorRef client = sys.actorOf(ContactClient.props(), "client");
        final ActorRef server = sys.actorOf(ContactServer.props(), "server");

        server.tell(new PutMessage("mariorossi", "mario.rossi@polimi.it"), client);
        server.tell(new GetMessage("mariorossi"), client);
        server.tell(new GetMessage("francescoverdi"), client);

        //noinspection ResultOfMethodCallIgnored
        System.in.read();
        sys.terminate();
    }
}
