package com.practice.exercise1.message;

public class IncreaseMessage implements MessageInterface {
}
