package com.practice.exercise4;

import akka.actor.AbstractActor;
import com.practice.exercise4.exception.AlphaException;
import com.practice.exercise4.exception.BetaException;
import com.practice.exercise4.exception.GammaException;
import com.practice.exercise4.message.AlphaMessage;
import com.practice.exercise4.message.BetaMessage;
import com.practice.exercise4.message.GammaMessage;

import java.util.Optional;

public class CounterActor extends AbstractActor {

    private int counter = 0;

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(AlphaMessage.class, this::onAlphaMessage)
                .match(BetaMessage.class, this::onBetaMessage)
                .match(GammaMessage.class, this::onGammaMessage)
                .build();
    }

    private void onAlphaMessage(AlphaMessage msg) throws AlphaException {
        if (msg.getOpCode() == Counter.NORMAL_OP) {
            counter++;
            System.out.println("ACTOR: I am executing an ALPHA-TYPE operation. Counter is now: " + counter);
        } else if (msg.getOpCode() == Counter.FAULT_OP) {
            System.out.println("ACTOR: I am emulating an ALPHA-TYPE fault");
            throw new AlphaException();
        }
    }

    private void onBetaMessage(BetaMessage msg) throws BetaException {
        if (msg.getOpCode() == Counter.NORMAL_OP) {
            counter--;
            System.out.println("ACTOR: I am executing an BETA-TYPE operation. Counter is now: " + counter);
        } else if (msg.getOpCode() == Counter.FAULT_OP) {
            System.out.println("ACTOR: I am emulating an BETA-TYPE fault");
            throw new BetaException();
        }
    }

    private void onGammaMessage(GammaMessage msg) throws GammaException {
        if (msg.getOpCode() == Counter.NORMAL_OP) {
            counter *= 2;
            System.out.println("ACTOR: I am executing an GAMMA-TYPE operation. Counter is now: " + counter);
        } else if (msg.getOpCode() == Counter.FAULT_OP) {
            System.out.println("ACTOR: I am emulating an GAMMA-TYPE fault");
            throw new GammaException();
        }
    }

    @Override
    public void preRestart(Throwable reason, Optional<Object> message) {
        System.out.println("Preparing to restart...");
    }

    @Override
    public void postRestart(Throwable reason) {
        System.out.println("... restarted!");
    }
}
