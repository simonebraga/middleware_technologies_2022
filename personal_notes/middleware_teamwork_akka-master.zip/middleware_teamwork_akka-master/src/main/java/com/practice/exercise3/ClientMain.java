package com.practice.exercise3;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import com.practice.exercise3.message.StartMessage;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.File;
import java.io.IOException;

// RUN ServerMain BEFORE

public class ClientMain {

    public static void main(String[] args) throws IOException {

        final Config config = ConfigFactory.parseFile(new File("src/main/resources/client.conf"));
        final ActorSystem clientSystem = ActorSystem.create("ClientSystem", config);
        clientSystem.actorOf(ClientActor.props(), "ClientActor").tell(new StartMessage(), ActorRef.noSender());

        //noinspection ResultOfMethodCallIgnored
        System.in.read();
        clientSystem.terminate();
    }
}
