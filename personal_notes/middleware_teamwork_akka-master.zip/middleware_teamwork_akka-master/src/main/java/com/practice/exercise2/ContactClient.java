package com.practice.exercise2;

import akka.actor.AbstractActor;
import akka.actor.Props;
import com.practice.exercise2.message.ResponseMessage;

public class ContactClient extends AbstractActor {

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(ResponseMessage.class, this::onResponseMessage)
                .build();
    }

    private void onResponseMessage(ResponseMessage msg) {
        if (msg.getValue() != null)
            System.out.println("CLIENT: I received <" + msg.getValue() + ">");
        else
            System.out.println("CLIENT: I received a null message");
    }

    static Props props() {
        return Props.create(ContactClient.class);
    }
}
