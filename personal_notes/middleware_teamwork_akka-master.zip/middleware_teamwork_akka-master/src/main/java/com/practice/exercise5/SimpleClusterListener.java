package com.practice.exercise5;

import akka.actor.AbstractActor;
import akka.actor.Props;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent;

public class SimpleClusterListener extends AbstractActor {

    Cluster cluster = Cluster.get(getContext().getSystem());

    @Override
    public void preStart() {
        cluster.subscribe(
                getSelf(), ClusterEvent.initialStateAsEvents(), ClusterEvent.MemberEvent.class
        );
    }

    @Override
    public void postStop() {
        cluster.unsubscribe(getSelf());
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(ClusterEvent.MemberUp.class, memberUp -> System.out.println("Member is up: " + memberUp.member()))
                .match(ClusterEvent.UnreachableMember.class, unreachableMember -> System.out.println("Member detected as unreachable: " + unreachableMember.member()))
                .match(ClusterEvent.MemberRemoved.class, memberRemoved -> System.out.println("Member is removed: " + memberRemoved.member()))
                .match(ClusterEvent.MemberEvent.class, memberEvent -> {})
                .build();
    }

    static Props props() {
        return Props.create(SimpleClusterListener.class);
    }
}