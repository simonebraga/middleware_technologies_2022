package com.practice.exercise3;

import akka.actor.ActorSystem;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.File;
import java.io.IOException;

public class ServerMain {

    public static void main(String[] args) throws IOException {

        final Config config = ConfigFactory.parseFile(new File("src/main/resources/server.conf"));
        final ActorSystem serverSystem = ActorSystem.create("ServerSystem", config);
        serverSystem.actorOf(ServerActor.props(), "ServerActor");

        //noinspection ResultOfMethodCallIgnored
        System.in.read();
        serverSystem.terminate();
    }
}
