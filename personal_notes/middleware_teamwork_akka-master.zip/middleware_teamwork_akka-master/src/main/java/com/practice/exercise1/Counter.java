package com.practice.exercise1;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import com.practice.exercise1.message.*;

public class Counter {

	private static final int numMessages = 100;

	public static void main(String[] args) throws InterruptedException, IOException {

		final ActorSystem sys = ActorSystem.create("System");
		final ActorRef counter = sys.actorOf(CounterActor.props(), "counter");

		for (int i = 0; i < numMessages; i++) {

			TimeUnit.MILLISECONDS.sleep(500);

			MessageInterface message;

			switch ((int) (Math.random() * 3)) {
				case 0: message = new IncreaseMessage(); break;
				case 1: message = new DecreaseMessage(); break;
				case 2: message = new DeltaMessage(); break;
				default: message = null;
			}

			counter.tell(message, ActorRef.noSender());

			if (Math.random() < 0.2) {
				TimeUnit.MILLISECONDS.sleep(300);
				counter.tell(new StateMessage(), ActorRef.noSender());
			}
		}

		//noinspection ResultOfMethodCallIgnored
		System.in.read();
		sys.terminate();

	}

}
