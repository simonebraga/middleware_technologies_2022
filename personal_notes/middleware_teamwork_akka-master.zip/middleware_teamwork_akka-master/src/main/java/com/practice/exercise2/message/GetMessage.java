package com.practice.exercise2.message;

public class GetMessage implements MessageInterface {

    private final String key;

    public GetMessage(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
