# Teamwork repository for Kafka
* [Java 11](https://openjdk.java.net/)
* [Maven 3.6.3](https://maven.apache.org/)
* [Kafka 3.0.0](https://kafka.apache.org/)
