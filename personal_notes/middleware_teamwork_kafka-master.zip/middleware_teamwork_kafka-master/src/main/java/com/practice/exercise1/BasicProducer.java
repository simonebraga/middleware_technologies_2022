package com.practice.exercise1;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class BasicProducer {

    public static final String topic = "exercise1A";

    private static final String serverAddress = "localhost:9092";

    private static String strGen() {
        return "RandomEvent" + (int) (Math.random() * 9999);
    }

    private static Properties getProps() {

        final Properties properties = new Properties();

        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddress);
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        return properties;
    }

    public static void main(String[] args) throws InterruptedException {

        KafkaProducer<String, String> producer = new KafkaProducer<>(getProps());

        //noinspection InfiniteLoopStatement
        while (true) {
            TimeUnit.SECONDS.sleep(1);

            final ProducerRecord<String, String> record = new ProducerRecord<>(topic, null, strGen());
            producer.send(record);
            System.out.println("Key: " + record.key() +
                    "\tValue: " + record.value() +
                    "\t! SENT !");
        }
    }
}
