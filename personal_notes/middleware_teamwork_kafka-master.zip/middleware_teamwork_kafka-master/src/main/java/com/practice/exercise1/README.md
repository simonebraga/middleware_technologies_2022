## Setup
Before starting anything, the following commands must be run on terminal.

*Run Kafka*
```
$ bin/zookeeper-server-start.sh config/zookeeper.properties
$ bin/kafka-server-start.sh config/server.properties
```

*Create topics*
```
$ bin/kafka-topics.sh --create --topic exercise1A --bootstrap-server localhost:9092 --partitions 20 --replication-factor 1
$ bin/kafka-topics.sh --create --topic exercise1B --bootstrap-server localhost:9092 --partitions 20 --replication-factor 1
```

## Run
You can run the classes in any order. Experiment different combinations to see different behaviors.
To clear all the streams just stop Kafka and Zookeper, then run
```
$ rm -rf /tmp/kafka-logs /tmp/zookeeper
```

### Disclaimer
Please notice that all the previous commands are written for **Ubuntu 20.04.3 LTS**.