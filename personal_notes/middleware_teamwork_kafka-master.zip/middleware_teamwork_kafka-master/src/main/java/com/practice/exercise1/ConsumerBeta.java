package com.practice.exercise1;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Properties;

public class ConsumerBeta {

    public static final String topicIn = "exercise1A";
    public static final String topicOut = "exercise1B";

    public static final String groupId = "groupC2";
    private static final String serverAddress = "localhost:9092";
    private static final boolean autoCommit = true;
    private static final int autoCommitInterval = 15000;

    private static final String offsetResetStrategy = "latest";

    @SuppressWarnings("DuplicatedCode")
    private static Properties getPropsIn() {

        final Properties properties = new Properties();

        properties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddress);
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, String.valueOf(autoCommit));
        properties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, String.valueOf(autoCommitInterval));
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetResetStrategy);

        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

        return properties;
    }

    private static Properties getPropsOut() {

        final Properties properties = new Properties();

        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddress);
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        return properties;
    }

    public static void main(String[] args) {

        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(getPropsIn());
        consumer.subscribe(Collections.singletonList(topicIn));

        KafkaProducer<String, String> producer = new KafkaProducer<>(getPropsOut());

        //noinspection InfiniteLoopStatement
        while (true) {
            final ConsumerRecords<String, String> inRecords = consumer.poll(Duration.of(5, ChronoUnit.MINUTES));
            for (final ConsumerRecord<String, String> inRecord : inRecords) {
                final String processed = inRecord.value().toUpperCase();
                System.out.println("Partition: " + inRecord.partition() +
                        "\tOffset: " + inRecord.offset() +
                        "\tKey: " + inRecord.key() +
                        "\tValue: " + inRecord.value() +
                        "\t! PROCESSED !");
                final ProducerRecord<String, String> outRecord = new ProducerRecord<>(topicOut, inRecord.key(), processed);
                producer.send(outRecord);
            }
        }
    }
}
