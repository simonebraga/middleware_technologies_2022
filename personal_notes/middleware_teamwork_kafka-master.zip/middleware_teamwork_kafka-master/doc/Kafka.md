
# Table of Contents

1.  [Operazioni da terminale](#org89b93e3)
    1.  [Start di `zookeeper`](#org554892f)
    2.  [Start del cluster di Kafka](#orgd0ac6d5)
    3.  [Creare un `topic`](#orgc3cc8b2)
    4.  [Visualizzare tutti i topic](#org993060f)
    5.  [Visualizzare informazioni su un topic](#orgf64625c)
    6.  [Scrivere `events` in modo interattivo](#orgaaa43e6)
    7.  [Leggere eventi](#org50b7bc5)
2.  [Java API](#org794538a)
    1.  [Proprietà](#orgc6f598e)
    2.  [Producer](#org8a547e9)
    3.  [Consumer](#org64aded4)
    4.  [Pipeline di producer/consumer](#org349eeb2)
    5.  [Admin](#org82e6e05)
        1.  [Ispezionare i topic](#orge7eb08c)
        2.  [Cancellare dei topic](#org99f7cc6)
        3.  [Aggiungere un topic](#orgb18c7d4)



<a id="org89b93e3"></a>

# Operazioni da terminale

Kafka viene distribuito con degli helper script che aiutano a gestire le istanze. Nel [quickstart](https://kafka.apache.org/quickstart) vengono definite le principali.

Assumendo si sia nella cartella che contiene la distribuzione di Kafka:


<a id="org554892f"></a>

## Start di `zookeeper`

    bin/zookeeper-server-start.sh config/zookeeper.properties

Per uscire, si può premere Ctrl-C.


<a id="orgd0ac6d5"></a>

## Start del cluster di Kafka

    bin/kafka-server-start.sh config/server.properties

Per uscire, si può premere Ctrl-C.


<a id="orgc3cc8b2"></a>

## Creare un `topic`

    bin/kafka-topics.sh --create --topic topicname --partitions n --replication-factor m --bootstrap-server localhost:9092

Dove `topicname` è il nome del topic che si vuole creare, `n` e `m` sono autoesplicativi. Nota: 9092 è la porta di default di Kafka, e il `bootstrap-server` svolge circa la stessa funzione dei seed in Akka.


<a id="org993060f"></a>

## Visualizzare tutti i topic

    bin/kafka-topics.sh --list --bootstrap-server localhost:9092


<a id="orgf64625c"></a>

## Visualizzare informazioni su un topic

    bin/kafka-topics.sh --describe --topic topicname --bootstrap-server localhost:9092

Dove topicname è il nome del topic di cui si vuole visualizzare le informazioni.


<a id="orgaaa43e6"></a>

## Scrivere `events` in modo interattivo

    bin/kafka-console-producer.sh --topic topicname --bootstrap-server localhost:9092

Dove topicname è il nome del topic su cui si vuole scrivere. A questo punto ogni riga inserita verrà inserita come nuovo evento nel topic selezionato. Per uscire si può premere Ctrl-C.


<a id="org50b7bc5"></a>

## Leggere eventi

    bin/kafka-console-consumer.sh --topic topicname --from-beginning --bootstrap-server localhost:9092

Dove topicname è il nome del topic da cui leggere. l'opzione `--from-beginning` indica che si vuole visualizzare tutto il log disponibile. Per uscire, si può premere Ctrl-C.


<a id="org794538a"></a>

# Java API

Per la documentazione si veda il [javadoc](https://kafka.apache.org/30/javadoc/index.html).


<a id="orgc6f598e"></a>

## Proprietà

In genere per passare le proprietà all'applicazione si usa un oggetto `Proprerties` (`java.util.Proprerties`), in modo simile a questo:

    final Properties props = new Properties();
          props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddr);
          props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
          props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

dove `ProducerConfig` fa parte di `org.apache.kafka.clients.producer`.


<a id="org8a547e9"></a>

## Producer

Si può ora creare il produttore di eventi, in questo modo:

    final KafkaProducer<KeyType, ValueType> producer = new KafkaProducer<>(props);

dove `KeyType` e `ValueType` sono gli opportuni tipi per chiave e valore degli event.

Ora, per committare un evento, bisogna crearlo tramite la classe `ProducerRecord`:

    final ProducerRecord<KeyType, ValueType> record = new ProducerRecord<>(topic, key, value);

Si può ora inviarlo usando il metodo `send(record)` del `KafkaProducer`, che restituisce un `Future<RecordMetadata>`:

    final Future<RecordMetadata> future = producer.send(record);

Ora l'evento è stato inviato.

La classe `RecordMetadata` rappresenta un **ack** che fornisce i metodi getter `topic()`, `partition()` e `offset()`.

    RecordMetadata ack = future.get();
    	  System.out.println("Ack for topic " + ack.topic() + ", partition " + ack.partition() + ", offset " + ack.offset())

Ricordarsi di chiudere il `KafkaProducer` con:

    producer.close();


<a id="org64aded4"></a>

## Consumer

Esiste anche `KafkaConsumer`. Si creano le proprietà in modo simile al producer:

    final Properties consProps = new Properties();
          consProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddr);
          consProps.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
          consProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, String.valueOf(autoCommit));
          consProps.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, String.valueOf(autoCommitIntervalMs));
    
          consProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetResetStrategy);
    
          consProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
          consProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

Poi possiamo creare il vero `KafkaConsumer` e fare `subscribe()` alla `List` di topics a cui siamo interessati (che sono quelli da cui il `KafkaConsumer` leggerà):

    KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consProps);
          consumer.subscribe(Arrays.asList("foo", "bar"));

Ora, per poter leggere, chiamiamo il metodo `poll()` sul `KafkaConsumer`. Questo restituirà un oggetto `ConsumerRecords`, che è un **container**. Offre una lista di `ConsumerRecord` per partizione per un determinato topic. Ogni `ConsumerRecord` offre i getter `offset()`, `key()` e `value()`. Come parametro a `poll()` viene data una `Duration` che indica un timeout: se nessun messaggio viene rilevato entro il timeout, viene ritornato un record vuoto.

    	ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
    for (ConsumerRecord<String, String> record : records)
        System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());


<a id="org349eeb2"></a>

## Pipeline di producer/consumer

Ovviamente si possono costruire catene di producer/consumer. Le costruzioni dei singoli oggetti sono le stesse. Il codice dei professori consiglia di avere l'oggetto `Process` che contiene come campi, oltre alle configurazioni, il `KafkaProducer` e il `KafkaConsumer`. Si avrrà un costruttore

    public Process(KafkaConsumer<String, String> consumer, KafkaProducer<String, String> producer)
      {
          this.consumer = consumer;
          this.producer = producer;
      }

che viene chiamato (nel codice dei prof nel `main`, ad esempio). Viene poi usato un metodo helper che concettualmente agisce come un thread loop infinito che processa i messaggi quando arrivano:

        ProcessConsumer s = new ProcessConsumer(consumer, producer);
    	  s.spinUp();
    
    public void spinUp() {
    	while (true) {
    	    final ConsumerRecords<String, String> records = consumer.poll(Duration.of(5, ChronoUnit.MINUTES));
    	    records.forEach(this::handleMessage);
    	}
        }

Da notare l'uso di **Java functional**. Il metodo handler che gestisce ogni messaggio può essere tipo:

    void handleMessage(ConsumerRecord<String, String> record) {
          System.out.println("Received from topic: " + record.topic() + ", partition: " + record.partition());
          String processed = record.value().toUpperCase(Locale.ROOT);
    
          publishProcessed(record.key(), processed);
      }

Dove `publishProcessed` è un'altro helper che crea e invia un nuovo record:

    void publishProcessed(String key, String value) {
          final ProducerRecord<String, String> record = new ProducerRecord<>(pubTopic, key, value);
          final Future<RecordMetadata> future = producer.send(record);
    
          try {
    	  RecordMetadata ack = future.get();
    	  System.out.println("Ack for topic " + ack.topic() + ", partition " + ack.partition() + ", offset " + ack.offset());
          } catch (InterruptedException | ExecutionException e1) {
    	  e1.printStackTrace();
          }
      }


<a id="org82e6e05"></a>

## Admin

La interfaccia usata per gestire e ispezionare topic, broker, configurazioni e ACLs. Le istanze restituite dal metodo statico *`create()`* sono thread-safe, ma i `KafkaFutures` restituiti sono esguiti da un singolo thread, quindi il codice che usa i risultati non deve bloccare troppo a lungo, oppure dovrebbe passarli ad un altro thread (copiato dalla [documentazione](https://kafka.apache.org/30/javadoc/org/apache/kafka/clients/admin/Admin.html).
Nota: il codice dei professori usa in realtà la classe `AdminClient`, ma la documentazione suggerisce di usare direttamente l'interfaccia.

Si crea con una configurazione tramite `Proprerties` e con il metodo statico *`create()`*:

    Properties props = new Properties();
          props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, serverAddr);
          AdminClient adminClient = AdminClient.create(props);

I metodi che espongono operazioni `xxx` sono eseguiti in maniera asincrona, e restituiscono oggetti chiamati `xxxResult`. Questi implementano la interfaccia `KafkaFuture` per accedere ai risultati dell'operazioni. Per avere un comportamento sincrono chiamare il metodo `get()`. I `KafkaFuture` offrono anche il metodo `all()`, che generalmenterestituisce un nuovo `KafkaFuture` che ha successo solo se tutte le operazioni del future sono state eseguite (quindi se ho capito bene una chiamata come `variableResult.all().get()` ritorna solo quando tutte le operazioni hanno avuto successo)


<a id="orge7eb08c"></a>

### Ispezionare i topic

    ListTopicsResult listResult = adminClient.listTopics();
          Set<String> topicsNames = listResult.names().get();
          System.out.println("Available topics: " + topicsNames);


<a id="org99f7cc6"></a>

### Cancellare dei topic

    if (topicsNames.contains(topicName)) {
    	  System.out.println("Deleting topic " + topicName);
    	  DeleteTopicsResult delResult = adminClient.deleteTopics(Collections.singletonList(topicName));
    	  delResult.all().get();
    	  System.out.println("Done!");
    	  // Wait for the deletion
    	  Thread.sleep(5000);
          }


<a id="orgb18c7d4"></a>

### Aggiungere un topic

    System.out.println("Adding topic " + topicName + " with " + topicPartitions + " partitions");
          NewTopic newTopic = new NewTopic(topicName, topicPartitions, replicationFactor);
          CreateTopicsResult createResult = adminClient.createTopics(Collections.singletonList(newTopic));
          createResult.all().get();
          System.out.println("Done!");

