# Teamwork repository for Spark
* [Java 11](https://openjdk.java.net/)
* [Maven 3.6.3](https://maven.apache.org/)
* [Spark 3.2.0 (Scala 2.13)](https://spark.apache.org/)